Different Windows versions Boot Sector/MBR (Master Boot Record).
Disks maybe not work because it's only Boot Sector
To find Boot Sector file:
The first letter is says which version.

Example:
BootSector98SE.bin
          ^^^^
Windows 98 SE MBR

BootSector1.0.img
          ^^^
Windows 1.0 MBR